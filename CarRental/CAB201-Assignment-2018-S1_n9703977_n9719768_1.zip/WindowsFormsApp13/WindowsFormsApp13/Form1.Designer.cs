﻿namespace WindowsFormsApp13
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.add_vehicle_button = new System.Windows.Forms.Button();
            this.remove_vehicle_button = new System.Windows.Forms.Button();
            this.modify_vehicle_button = new System.Windows.Forms.Button();
            this.mod_vehicle_groupbox = new System.Windows.Forms.GroupBox();
            this.mod_gps_combobox = new System.Windows.Forms.ComboBox();
            this.mod_sunroof_combobox = new System.Windows.Forms.ComboBox();
            this.mod_year_exclaim = new System.Windows.Forms.Label();
            this.mod_class_exclaim = new System.Windows.Forms.Label();
            this.mod_model_exclaim = new System.Windows.Forms.Label();
            this.mod_make_exclaim = new System.Windows.Forms.Label();
            this.mod_rego_exclaim = new System.Windows.Forms.Label();
            this.mod_dailyrate_updown = new System.Windows.Forms.NumericUpDown();
            this.mod_colour_textbox = new System.Windows.Forms.TextBox();
            this.mod_seats_updown = new System.Windows.Forms.NumericUpDown();
            this.mod_fuel_combobox = new System.Windows.Forms.ComboBox();
            this.mod_trans_combobox = new System.Windows.Forms.ComboBox();
            this.mod_year_textbox = new System.Windows.Forms.TextBox();
            this.mod_class_combobox = new System.Windows.Forms.ComboBox();
            this.mod_model_textbox = new System.Windows.Forms.TextBox();
            this.mod_make_textbox = new System.Windows.Forms.TextBox();
            this.mod_rego_textbox = new System.Windows.Forms.TextBox();
            this.vehicle_cancel_button = new System.Windows.Forms.Button();
            this.vehicle_submit_button = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dataGridViewVehicles = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cust_main_groupbox = new System.Windows.Forms.GroupBox();
            this.add_cust_button = new System.Windows.Forms.Button();
            this.modify_cust_button = new System.Windows.Forms.Button();
            this.remove_cust_button = new System.Windows.Forms.Button();
            this.mod_add_cust_groupbox = new System.Windows.Forms.GroupBox();
            this.mod_cust_id_exclaim = new System.Windows.Forms.Label();
            this.gender_select = new System.Windows.Forms.ComboBox();
            this.mod_cust_dob_exclaim = new System.Windows.Forms.Label();
            this.mod_cust_gender_exclaim = new System.Windows.Forms.Label();
            this.mod_cust_ln_exclaim = new System.Windows.Forms.Label();
            this.mod_cust_title_exclaim = new System.Windows.Forms.Label();
            this.mod_cust_fn_exclaim = new System.Windows.Forms.Label();
            this.mod_cust_submit_button = new System.Windows.Forms.Button();
            this.mod_cust_cancel_button = new System.Windows.Forms.Button();
            this.mod_dob_textbox = new System.Windows.Forms.TextBox();
            this.mod_ln_textbox = new System.Windows.Forms.TextBox();
            this.mod_fn_textbox = new System.Windows.Forms.TextBox();
            this.mod_title_textbox = new System.Windows.Forms.TextBox();
            this.mod_custid_textbox = new System.Windows.Forms.TextBox();
            this.dob_label = new System.Windows.Forms.Label();
            this.gender_label = new System.Windows.Forms.Label();
            this.ln_label = new System.Windows.Forms.Label();
            this.fn_label = new System.Windows.Forms.Label();
            this.title_label = new System.Windows.Forms.Label();
            this.custid_label = new System.Windows.Forms.Label();
            this.dataGridViewCustomers = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.modify_rental_groupbox = new System.Windows.Forms.GroupBox();
            this.rental_summary_label = new System.Windows.Forms.Label();
            this.return_vehicle_button = new System.Windows.Forms.Button();
            this.dataGridViewRentals = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.results_groupbox = new System.Windows.Forms.GroupBox();
            this.dataGridViewSearch = new System.Windows.Forms.DataGridView();
            this.create_rental_groupbox = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rental_days_select = new System.Windows.Forms.NumericUpDown();
            this.customer_combobox = new System.Windows.Forms.ComboBox();
            this.rent_confirm_button = new System.Windows.Forms.Button();
            this.total_cost_label = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.max_price_search = new System.Windows.Forms.NumericUpDown();
            this.min_price_search = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.show_all_button = new System.Windows.Forms.Button();
            this.search_button = new System.Windows.Forms.Button();
            this.search_input_textbox = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label10 = new System.Windows.Forms.Label();
            this.cust_renting_exclaim = new System.Windows.Forms.Label();
            this.days_renting_exclaim = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.mod_vehicle_groupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mod_dailyrate_updown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mod_seats_updown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVehicles)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.cust_main_groupbox.SuspendLayout();
            this.mod_add_cust_groupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomers)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.modify_rental_groupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRentals)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.results_groupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSearch)).BeginInit();
            this.create_rental_groupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rental_days_select)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.max_price_search)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.min_price_search)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 21.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(448, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "MATES RATES RENT A CAR";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(228, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Management Portal";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabControl1.Location = new System.Drawing.Point(12, 120);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1400, 639);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.mod_vehicle_groupbox);
            this.tabPage1.Controls.Add(this.dataGridViewVehicles);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1392, 613);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Fleet";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.add_vehicle_button);
            this.groupBox4.Controls.Add(this.remove_vehicle_button);
            this.groupBox4.Controls.Add(this.modify_vehicle_button);
            this.groupBox4.Location = new System.Drawing.Point(6, 538);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1380, 69);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Modify Fleet";
            // 
            // add_vehicle_button
            // 
            this.add_vehicle_button.Location = new System.Drawing.Point(1200, 19);
            this.add_vehicle_button.Name = "add_vehicle_button";
            this.add_vehicle_button.Size = new System.Drawing.Size(124, 33);
            this.add_vehicle_button.TabIndex = 27;
            this.add_vehicle_button.Text = "Add";
            this.add_vehicle_button.UseVisualStyleBackColor = true;
            this.add_vehicle_button.Click += new System.EventHandler(this.add_vehicle_button_Click);
            // 
            // remove_vehicle_button
            // 
            this.remove_vehicle_button.Location = new System.Drawing.Point(204, 19);
            this.remove_vehicle_button.Name = "remove_vehicle_button";
            this.remove_vehicle_button.Size = new System.Drawing.Size(124, 33);
            this.remove_vehicle_button.TabIndex = 26;
            this.remove_vehicle_button.Text = "Remove";
            this.remove_vehicle_button.UseVisualStyleBackColor = true;
            this.remove_vehicle_button.Click += new System.EventHandler(this.remove_vehicle_button_Click);
            // 
            // modify_vehicle_button
            // 
            this.modify_vehicle_button.Location = new System.Drawing.Point(52, 19);
            this.modify_vehicle_button.Name = "modify_vehicle_button";
            this.modify_vehicle_button.Size = new System.Drawing.Size(124, 33);
            this.modify_vehicle_button.TabIndex = 25;
            this.modify_vehicle_button.Text = "Modify";
            this.modify_vehicle_button.UseVisualStyleBackColor = true;
            this.modify_vehicle_button.Click += new System.EventHandler(this.modify_vehicle_button_Click);
            // 
            // mod_vehicle_groupbox
            // 
            this.mod_vehicle_groupbox.Controls.Add(this.mod_gps_combobox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_sunroof_combobox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_year_exclaim);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_class_exclaim);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_model_exclaim);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_make_exclaim);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_rego_exclaim);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_dailyrate_updown);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_colour_textbox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_seats_updown);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_fuel_combobox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_trans_combobox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_year_textbox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_class_combobox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_model_textbox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_make_textbox);
            this.mod_vehicle_groupbox.Controls.Add(this.mod_rego_textbox);
            this.mod_vehicle_groupbox.Controls.Add(this.vehicle_cancel_button);
            this.mod_vehicle_groupbox.Controls.Add(this.vehicle_submit_button);
            this.mod_vehicle_groupbox.Controls.Add(this.label21);
            this.mod_vehicle_groupbox.Controls.Add(this.label20);
            this.mod_vehicle_groupbox.Controls.Add(this.label19);
            this.mod_vehicle_groupbox.Controls.Add(this.label18);
            this.mod_vehicle_groupbox.Controls.Add(this.label17);
            this.mod_vehicle_groupbox.Controls.Add(this.label16);
            this.mod_vehicle_groupbox.Controls.Add(this.label15);
            this.mod_vehicle_groupbox.Controls.Add(this.label14);
            this.mod_vehicle_groupbox.Controls.Add(this.label13);
            this.mod_vehicle_groupbox.Controls.Add(this.label12);
            this.mod_vehicle_groupbox.Controls.Add(this.label11);
            this.mod_vehicle_groupbox.Controls.Add(this.label9);
            this.mod_vehicle_groupbox.Location = new System.Drawing.Point(6, 294);
            this.mod_vehicle_groupbox.Name = "mod_vehicle_groupbox";
            this.mod_vehicle_groupbox.Size = new System.Drawing.Size(1380, 238);
            this.mod_vehicle_groupbox.TabIndex = 1;
            this.mod_vehicle_groupbox.TabStop = false;
            // 
            // mod_gps_combobox
            // 
            this.mod_gps_combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mod_gps_combobox.FormattingEnabled = true;
            this.mod_gps_combobox.Location = new System.Drawing.Point(1164, 40);
            this.mod_gps_combobox.Name = "mod_gps_combobox";
            this.mod_gps_combobox.Size = new System.Drawing.Size(160, 21);
            this.mod_gps_combobox.TabIndex = 42;
            this.toolTip1.SetToolTip(this.mod_gps_combobox, "Please make a selection.");
            // 
            // mod_sunroof_combobox
            // 
            this.mod_sunroof_combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mod_sunroof_combobox.FormattingEnabled = true;
            this.mod_sunroof_combobox.Location = new System.Drawing.Point(816, 134);
            this.mod_sunroof_combobox.Name = "mod_sunroof_combobox";
            this.mod_sunroof_combobox.Size = new System.Drawing.Size(160, 21);
            this.mod_sunroof_combobox.TabIndex = 41;
            this.toolTip1.SetToolTip(this.mod_sunroof_combobox, "Please make a selection.");
            // 
            // mod_year_exclaim
            // 
            this.mod_year_exclaim.AutoSize = true;
            this.mod_year_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_year_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_year_exclaim.Location = new System.Drawing.Point(652, 87);
            this.mod_year_exclaim.Name = "mod_year_exclaim";
            this.mod_year_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_year_exclaim.TabIndex = 40;
            this.mod_year_exclaim.Text = "!";
            // 
            // mod_class_exclaim
            // 
            this.mod_class_exclaim.AutoSize = true;
            this.mod_class_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_class_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_class_exclaim.Location = new System.Drawing.Point(652, 38);
            this.mod_class_exclaim.Name = "mod_class_exclaim";
            this.mod_class_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_class_exclaim.TabIndex = 39;
            this.mod_class_exclaim.Text = "!";
            // 
            // mod_model_exclaim
            // 
            this.mod_model_exclaim.AutoSize = true;
            this.mod_model_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_model_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_model_exclaim.Location = new System.Drawing.Point(281, 140);
            this.mod_model_exclaim.Name = "mod_model_exclaim";
            this.mod_model_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_model_exclaim.TabIndex = 38;
            this.mod_model_exclaim.Text = "!";
            // 
            // mod_make_exclaim
            // 
            this.mod_make_exclaim.AutoSize = true;
            this.mod_make_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_make_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_make_exclaim.Location = new System.Drawing.Point(281, 90);
            this.mod_make_exclaim.Name = "mod_make_exclaim";
            this.mod_make_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_make_exclaim.TabIndex = 37;
            this.mod_make_exclaim.Text = "!";
            // 
            // mod_rego_exclaim
            // 
            this.mod_rego_exclaim.AutoSize = true;
            this.mod_rego_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_rego_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_rego_exclaim.Location = new System.Drawing.Point(281, 38);
            this.mod_rego_exclaim.Name = "mod_rego_exclaim";
            this.mod_rego_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_rego_exclaim.TabIndex = 36;
            this.mod_rego_exclaim.Text = "!";
            // 
            // mod_dailyrate_updown
            // 
            this.mod_dailyrate_updown.Location = new System.Drawing.Point(1164, 134);
            this.mod_dailyrate_updown.Maximum = new decimal(new int[] {
            276447232,
            23283,
            0,
            0});
            this.mod_dailyrate_updown.Name = "mod_dailyrate_updown";
            this.mod_dailyrate_updown.Size = new System.Drawing.Size(160, 20);
            this.mod_dailyrate_updown.TabIndex = 34;
            this.toolTip1.SetToolTip(this.mod_dailyrate_updown, "Please select a value.");
            // 
            // mod_colour_textbox
            // 
            this.mod_colour_textbox.Location = new System.Drawing.Point(1164, 86);
            this.mod_colour_textbox.Name = "mod_colour_textbox";
            this.mod_colour_textbox.Size = new System.Drawing.Size(160, 20);
            this.mod_colour_textbox.TabIndex = 33;
            this.toolTip1.SetToolTip(this.mod_colour_textbox, "Input must be in the form of a string.");
            // 
            // mod_seats_updown
            // 
            this.mod_seats_updown.Location = new System.Drawing.Point(816, 87);
            this.mod_seats_updown.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.mod_seats_updown.Name = "mod_seats_updown";
            this.mod_seats_updown.Size = new System.Drawing.Size(160, 20);
            this.mod_seats_updown.TabIndex = 30;
            this.toolTip1.SetToolTip(this.mod_seats_updown, "Please select a value.");
            this.mod_seats_updown.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // mod_fuel_combobox
            // 
            this.mod_fuel_combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mod_fuel_combobox.FormattingEnabled = true;
            this.mod_fuel_combobox.Location = new System.Drawing.Point(816, 40);
            this.mod_fuel_combobox.Name = "mod_fuel_combobox";
            this.mod_fuel_combobox.Size = new System.Drawing.Size(160, 21);
            this.mod_fuel_combobox.TabIndex = 29;
            this.toolTip1.SetToolTip(this.mod_fuel_combobox, "Please select an option.");
            // 
            // mod_trans_combobox
            // 
            this.mod_trans_combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mod_trans_combobox.FormattingEnabled = true;
            this.mod_trans_combobox.Location = new System.Drawing.Point(486, 134);
            this.mod_trans_combobox.Name = "mod_trans_combobox";
            this.mod_trans_combobox.Size = new System.Drawing.Size(160, 21);
            this.mod_trans_combobox.TabIndex = 28;
            this.toolTip1.SetToolTip(this.mod_trans_combobox, "Please select an option.");
            // 
            // mod_year_textbox
            // 
            this.mod_year_textbox.Location = new System.Drawing.Point(486, 87);
            this.mod_year_textbox.Name = "mod_year_textbox";
            this.mod_year_textbox.Size = new System.Drawing.Size(160, 20);
            this.mod_year_textbox.TabIndex = 27;
            this.toolTip1.SetToolTip(this.mod_year_textbox, "Required field. Input must be a an integer from 1800 - 2018.\r\n");
            this.mod_year_textbox.TextChanged += new System.EventHandler(this.mod_year_textbox_TextChanged);
            // 
            // mod_class_combobox
            // 
            this.mod_class_combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mod_class_combobox.FormattingEnabled = true;
            this.mod_class_combobox.Location = new System.Drawing.Point(486, 39);
            this.mod_class_combobox.Name = "mod_class_combobox";
            this.mod_class_combobox.Size = new System.Drawing.Size(160, 21);
            this.mod_class_combobox.TabIndex = 26;
            this.toolTip1.SetToolTip(this.mod_class_combobox, "Required field. Please select an option.");
            this.mod_class_combobox.SelectedIndexChanged += new System.EventHandler(this.mod_class_combobox_TextChanged);
            this.mod_class_combobox.TextUpdate += new System.EventHandler(this.mod_class_combobox_TextChanged);
            this.mod_class_combobox.TextChanged += new System.EventHandler(this.mod_class_combobox_TextChanged);
            // 
            // mod_model_textbox
            // 
            this.mod_model_textbox.Location = new System.Drawing.Point(115, 139);
            this.mod_model_textbox.Name = "mod_model_textbox";
            this.mod_model_textbox.Size = new System.Drawing.Size(160, 20);
            this.mod_model_textbox.TabIndex = 25;
            this.toolTip1.SetToolTip(this.mod_model_textbox, "Required field. Input must be in the form of a string.");
            this.mod_model_textbox.TextChanged += new System.EventHandler(this.mod_model_textbox_TextChanged);
            // 
            // mod_make_textbox
            // 
            this.mod_make_textbox.Location = new System.Drawing.Point(115, 92);
            this.mod_make_textbox.Name = "mod_make_textbox";
            this.mod_make_textbox.Size = new System.Drawing.Size(160, 20);
            this.mod_make_textbox.TabIndex = 24;
            this.toolTip1.SetToolTip(this.mod_make_textbox, "Required field. Input must be in the form of a string.");
            this.mod_make_textbox.TextChanged += new System.EventHandler(this.mod_make_textbox_TextChanged);
            // 
            // mod_rego_textbox
            // 
            this.mod_rego_textbox.Location = new System.Drawing.Point(115, 40);
            this.mod_rego_textbox.Name = "mod_rego_textbox";
            this.mod_rego_textbox.Size = new System.Drawing.Size(160, 20);
            this.mod_rego_textbox.TabIndex = 23;
            this.toolTip1.SetToolTip(this.mod_rego_textbox, "Required field. Must be 3 numbers (0-9) followed by 3 upper case letters (A-Z).");
            this.mod_rego_textbox.TextChanged += new System.EventHandler(this.mod_rego_textbox_TextChanged);
            // 
            // vehicle_cancel_button
            // 
            this.vehicle_cancel_button.Location = new System.Drawing.Point(1200, 180);
            this.vehicle_cancel_button.Name = "vehicle_cancel_button";
            this.vehicle_cancel_button.Size = new System.Drawing.Size(124, 33);
            this.vehicle_cancel_button.TabIndex = 22;
            this.vehicle_cancel_button.Text = "Cancel";
            this.vehicle_cancel_button.UseVisualStyleBackColor = true;
            this.vehicle_cancel_button.Click += new System.EventHandler(this.vehicle_cancel_button_Click);
            // 
            // vehicle_submit_button
            // 
            this.vehicle_submit_button.Location = new System.Drawing.Point(1030, 180);
            this.vehicle_submit_button.Name = "vehicle_submit_button";
            this.vehicle_submit_button.Size = new System.Drawing.Size(124, 33);
            this.vehicle_submit_button.TabIndex = 21;
            this.vehicle_submit_button.Text = "Submit";
            this.vehicle_submit_button.UseVisualStyleBackColor = true;
            this.vehicle_submit_button.Click += new System.EventHandler(this.vehicle_submit_button_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(1055, 140);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(72, 15);
            this.label21.TabIndex = 11;
            this.label21.Text = "Daily rate:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(1074, 92);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 15);
            this.label20.TabIndex = 10;
            this.label20.Text = "Colour:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(1088, 45);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(39, 15);
            this.label19.TabIndex = 9;
            this.label19.Text = "GPS:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(734, 140);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 15);
            this.label18.TabIndex = 8;
            this.label18.Text = "Sunroof:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(748, 92);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 15);
            this.label17.TabIndex = 7;
            this.label17.Text = "Seats:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(756, 45);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 15);
            this.label16.TabIndex = 6;
            this.label16.Text = "Fuel:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(371, 140);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 15);
            this.label15.TabIndex = 5;
            this.label15.Text = "Transmission:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(428, 92);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 15);
            this.label14.TabIndex = 4;
            this.label14.Text = "Year:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(422, 45);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 15);
            this.label13.TabIndex = 3;
            this.label13.Text = "Class:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(49, 140);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 15);
            this.label12.TabIndex = 2;
            this.label12.Text = "Model:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(54, 92);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "Make:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(55, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 15);
            this.label9.TabIndex = 0;
            this.label9.Text = "Rego:";
            // 
            // dataGridViewVehicles
            // 
            this.dataGridViewVehicles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewVehicles.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewVehicles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVehicles.Location = new System.Drawing.Point(3, 6);
            this.dataGridViewVehicles.Name = "dataGridViewVehicles";
            this.dataGridViewVehicles.ReadOnly = true;
            this.dataGridViewVehicles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVehicles.Size = new System.Drawing.Size(1383, 282);
            this.dataGridViewVehicles.TabIndex = 0;
            this.dataGridViewVehicles.SelectionChanged += new System.EventHandler(this.dataGridViewVehicles_SelectionChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cust_main_groupbox);
            this.tabPage2.Controls.Add(this.mod_add_cust_groupbox);
            this.tabPage2.Controls.Add(this.dataGridViewCustomers);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1392, 613);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Customers";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cust_main_groupbox
            // 
            this.cust_main_groupbox.Controls.Add(this.add_cust_button);
            this.cust_main_groupbox.Controls.Add(this.modify_cust_button);
            this.cust_main_groupbox.Controls.Add(this.remove_cust_button);
            this.cust_main_groupbox.Location = new System.Drawing.Point(6, 539);
            this.cust_main_groupbox.Name = "cust_main_groupbox";
            this.cust_main_groupbox.Size = new System.Drawing.Size(1380, 68);
            this.cust_main_groupbox.TabIndex = 3;
            this.cust_main_groupbox.TabStop = false;
            this.cust_main_groupbox.Text = "Modify CRM";
            // 
            // add_cust_button
            // 
            this.add_cust_button.Location = new System.Drawing.Point(1231, 19);
            this.add_cust_button.Name = "add_cust_button";
            this.add_cust_button.Size = new System.Drawing.Size(124, 33);
            this.add_cust_button.TabIndex = 4;
            this.add_cust_button.Text = "Add";
            this.add_cust_button.UseVisualStyleBackColor = true;
            this.add_cust_button.Click += new System.EventHandler(this.add_cust_button_Click);
            // 
            // modify_cust_button
            // 
            this.modify_cust_button.Location = new System.Drawing.Point(23, 19);
            this.modify_cust_button.Name = "modify_cust_button";
            this.modify_cust_button.Size = new System.Drawing.Size(124, 33);
            this.modify_cust_button.TabIndex = 3;
            this.modify_cust_button.Text = "Modify";
            this.modify_cust_button.UseVisualStyleBackColor = true;
            this.modify_cust_button.Click += new System.EventHandler(this.modify_cust_button_Click);
            // 
            // remove_cust_button
            // 
            this.remove_cust_button.Location = new System.Drawing.Point(187, 19);
            this.remove_cust_button.Name = "remove_cust_button";
            this.remove_cust_button.Size = new System.Drawing.Size(124, 33);
            this.remove_cust_button.TabIndex = 2;
            this.remove_cust_button.Text = "Remove";
            this.remove_cust_button.UseVisualStyleBackColor = true;
            this.remove_cust_button.Click += new System.EventHandler(this.remove_cust_button_Click);
            // 
            // mod_add_cust_groupbox
            // 
            this.mod_add_cust_groupbox.Controls.Add(this.mod_cust_id_exclaim);
            this.mod_add_cust_groupbox.Controls.Add(this.gender_select);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_cust_dob_exclaim);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_cust_gender_exclaim);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_cust_ln_exclaim);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_cust_title_exclaim);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_cust_fn_exclaim);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_cust_submit_button);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_cust_cancel_button);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_dob_textbox);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_ln_textbox);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_fn_textbox);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_title_textbox);
            this.mod_add_cust_groupbox.Controls.Add(this.mod_custid_textbox);
            this.mod_add_cust_groupbox.Controls.Add(this.dob_label);
            this.mod_add_cust_groupbox.Controls.Add(this.gender_label);
            this.mod_add_cust_groupbox.Controls.Add(this.ln_label);
            this.mod_add_cust_groupbox.Controls.Add(this.fn_label);
            this.mod_add_cust_groupbox.Controls.Add(this.title_label);
            this.mod_add_cust_groupbox.Controls.Add(this.custid_label);
            this.mod_add_cust_groupbox.Location = new System.Drawing.Point(6, 294);
            this.mod_add_cust_groupbox.Name = "mod_add_cust_groupbox";
            this.mod_add_cust_groupbox.Size = new System.Drawing.Size(1380, 238);
            this.mod_add_cust_groupbox.TabIndex = 2;
            this.mod_add_cust_groupbox.TabStop = false;
            this.mod_add_cust_groupbox.Text = "Modify Customer";
            // 
            // mod_cust_id_exclaim
            // 
            this.mod_cust_id_exclaim.AutoSize = true;
            this.mod_cust_id_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_cust_id_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_cust_id_exclaim.Location = new System.Drawing.Point(281, 38);
            this.mod_cust_id_exclaim.Name = "mod_cust_id_exclaim";
            this.mod_cust_id_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_cust_id_exclaim.TabIndex = 20;
            this.mod_cust_id_exclaim.Text = "!";
            // 
            // gender_select
            // 
            this.gender_select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gender_select.FormattingEnabled = true;
            this.gender_select.Location = new System.Drawing.Point(1116, 43);
            this.gender_select.Name = "gender_select";
            this.gender_select.Size = new System.Drawing.Size(100, 21);
            this.gender_select.TabIndex = 19;
            this.toolTip1.SetToolTip(this.gender_select, "Required field. Please select \'Male\' or \'Female\'.");
            this.gender_select.SelectedIndexChanged += new System.EventHandler(this.gender_select_SelectedIndexChanged);
            this.gender_select.TextChanged += new System.EventHandler(this.gender_select_SelectedIndexChanged);
            // 
            // mod_cust_dob_exclaim
            // 
            this.mod_cust_dob_exclaim.AutoSize = true;
            this.mod_cust_dob_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_cust_dob_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_cust_dob_exclaim.Location = new System.Drawing.Point(1227, 130);
            this.mod_cust_dob_exclaim.Name = "mod_cust_dob_exclaim";
            this.mod_cust_dob_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_cust_dob_exclaim.TabIndex = 18;
            this.mod_cust_dob_exclaim.Text = "!";
            // 
            // mod_cust_gender_exclaim
            // 
            this.mod_cust_gender_exclaim.AutoSize = true;
            this.mod_cust_gender_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_cust_gender_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_cust_gender_exclaim.Location = new System.Drawing.Point(1226, 43);
            this.mod_cust_gender_exclaim.Name = "mod_cust_gender_exclaim";
            this.mod_cust_gender_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_cust_gender_exclaim.TabIndex = 17;
            this.mod_cust_gender_exclaim.Text = "!";
            // 
            // mod_cust_ln_exclaim
            // 
            this.mod_cust_ln_exclaim.AutoSize = true;
            this.mod_cust_ln_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_cust_ln_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_cust_ln_exclaim.Location = new System.Drawing.Point(756, 130);
            this.mod_cust_ln_exclaim.Name = "mod_cust_ln_exclaim";
            this.mod_cust_ln_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_cust_ln_exclaim.TabIndex = 16;
            this.mod_cust_ln_exclaim.Text = "!";
            // 
            // mod_cust_title_exclaim
            // 
            this.mod_cust_title_exclaim.AutoSize = true;
            this.mod_cust_title_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_cust_title_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_cust_title_exclaim.Location = new System.Drawing.Point(282, 130);
            this.mod_cust_title_exclaim.Name = "mod_cust_title_exclaim";
            this.mod_cust_title_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_cust_title_exclaim.TabIndex = 15;
            this.mod_cust_title_exclaim.Text = "!";
            // 
            // mod_cust_fn_exclaim
            // 
            this.mod_cust_fn_exclaim.AutoSize = true;
            this.mod_cust_fn_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod_cust_fn_exclaim.ForeColor = System.Drawing.Color.Red;
            this.mod_cust_fn_exclaim.Location = new System.Drawing.Point(756, 40);
            this.mod_cust_fn_exclaim.Name = "mod_cust_fn_exclaim";
            this.mod_cust_fn_exclaim.Size = new System.Drawing.Size(15, 20);
            this.mod_cust_fn_exclaim.TabIndex = 14;
            this.mod_cust_fn_exclaim.Text = "!";
            // 
            // mod_cust_submit_button
            // 
            this.mod_cust_submit_button.Location = new System.Drawing.Point(1069, 187);
            this.mod_cust_submit_button.Name = "mod_cust_submit_button";
            this.mod_cust_submit_button.Size = new System.Drawing.Size(124, 33);
            this.mod_cust_submit_button.TabIndex = 13;
            this.mod_cust_submit_button.Text = "Submit";
            this.mod_cust_submit_button.UseVisualStyleBackColor = true;
            this.mod_cust_submit_button.Click += new System.EventHandler(this.mod_cust_submit_button_Click);
            // 
            // mod_cust_cancel_button
            // 
            this.mod_cust_cancel_button.Location = new System.Drawing.Point(1231, 187);
            this.mod_cust_cancel_button.Name = "mod_cust_cancel_button";
            this.mod_cust_cancel_button.Size = new System.Drawing.Size(124, 33);
            this.mod_cust_cancel_button.TabIndex = 12;
            this.mod_cust_cancel_button.Text = "Cancel";
            this.mod_cust_cancel_button.UseVisualStyleBackColor = true;
            this.mod_cust_cancel_button.Click += new System.EventHandler(this.mod_cust_cancel_button_Click);
            // 
            // mod_dob_textbox
            // 
            this.mod_dob_textbox.Location = new System.Drawing.Point(1116, 132);
            this.mod_dob_textbox.Name = "mod_dob_textbox";
            this.mod_dob_textbox.Size = new System.Drawing.Size(100, 20);
            this.mod_dob_textbox.TabIndex = 11;
            this.toolTip1.SetToolTip(this.mod_dob_textbox, "Required field. Input must be in DD/MM/YYYY format.");
            this.mod_dob_textbox.TextChanged += new System.EventHandler(this.mod_dob_textbox_TextChanged);
            // 
            // mod_ln_textbox
            // 
            this.mod_ln_textbox.Location = new System.Drawing.Point(650, 132);
            this.mod_ln_textbox.Name = "mod_ln_textbox";
            this.mod_ln_textbox.Size = new System.Drawing.Size(100, 20);
            this.mod_ln_textbox.TabIndex = 9;
            this.toolTip1.SetToolTip(this.mod_ln_textbox, "Required field. Input must be in the form of a string.");
            this.mod_ln_textbox.TextChanged += new System.EventHandler(this.mod_ln_textbox_TextChanged);
            // 
            // mod_fn_textbox
            // 
            this.mod_fn_textbox.Location = new System.Drawing.Point(650, 40);
            this.mod_fn_textbox.Name = "mod_fn_textbox";
            this.mod_fn_textbox.Size = new System.Drawing.Size(100, 20);
            this.mod_fn_textbox.TabIndex = 8;
            this.toolTip1.SetToolTip(this.mod_fn_textbox, "Required field. Input must be in the form of a string.");
            this.mod_fn_textbox.TextChanged += new System.EventHandler(this.mod_fn_textbox_TextChanged);
            // 
            // mod_title_textbox
            // 
            this.mod_title_textbox.Location = new System.Drawing.Point(176, 132);
            this.mod_title_textbox.Name = "mod_title_textbox";
            this.mod_title_textbox.Size = new System.Drawing.Size(100, 20);
            this.mod_title_textbox.TabIndex = 7;
            this.toolTip1.SetToolTip(this.mod_title_textbox, "Required field. Input must be in the form of a string.");
            this.mod_title_textbox.TextChanged += new System.EventHandler(this.mod_title_textbox_TextChanged);
            // 
            // mod_custid_textbox
            // 
            this.mod_custid_textbox.Location = new System.Drawing.Point(176, 40);
            this.mod_custid_textbox.Name = "mod_custid_textbox";
            this.mod_custid_textbox.Size = new System.Drawing.Size(100, 20);
            this.mod_custid_textbox.TabIndex = 6;
            this.toolTip1.SetToolTip(this.mod_custid_textbox, "Required field. Input must be a unique integer.");
            this.mod_custid_textbox.TextChanged += new System.EventHandler(this.mod_custid_textbox_TextChanged);
            // 
            // dob_label
            // 
            this.dob_label.AutoSize = true;
            this.dob_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dob_label.Location = new System.Drawing.Point(1002, 137);
            this.dob_label.Name = "dob_label";
            this.dob_label.Size = new System.Drawing.Size(91, 15);
            this.dob_label.TabIndex = 5;
            this.dob_label.Text = "Date of Birth:";
            // 
            // gender_label
            // 
            this.gender_label.AutoSize = true;
            this.gender_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender_label.Location = new System.Drawing.Point(1035, 49);
            this.gender_label.Name = "gender_label";
            this.gender_label.Size = new System.Drawing.Size(58, 15);
            this.gender_label.TabIndex = 4;
            this.gender_label.Text = "Gender:";
            // 
            // ln_label
            // 
            this.ln_label.AutoSize = true;
            this.ln_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ln_label.Location = new System.Drawing.Point(555, 137);
            this.ln_label.Name = "ln_label";
            this.ln_label.Size = new System.Drawing.Size(80, 15);
            this.ln_label.TabIndex = 3;
            this.ln_label.Text = "Last Name:";
            // 
            // fn_label
            // 
            this.fn_label.AutoSize = true;
            this.fn_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fn_label.Location = new System.Drawing.Point(537, 45);
            this.fn_label.Name = "fn_label";
            this.fn_label.Size = new System.Drawing.Size(98, 15);
            this.fn_label.TabIndex = 2;
            this.fn_label.Text = "First Name(s):";
            // 
            // title_label
            // 
            this.title_label.AutoSize = true;
            this.title_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title_label.Location = new System.Drawing.Point(131, 137);
            this.title_label.Name = "title_label";
            this.title_label.Size = new System.Drawing.Size(39, 15);
            this.title_label.TabIndex = 1;
            this.title_label.Text = "Title:";
            // 
            // custid_label
            // 
            this.custid_label.AutoSize = true;
            this.custid_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.custid_label.Location = new System.Drawing.Point(80, 45);
            this.custid_label.Name = "custid_label";
            this.custid_label.Size = new System.Drawing.Size(90, 15);
            this.custid_label.TabIndex = 0;
            this.custid_label.Text = "Customer ID:";
            // 
            // dataGridViewCustomers
            // 
            this.dataGridViewCustomers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCustomers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCustomers.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewCustomers.MultiSelect = false;
            this.dataGridViewCustomers.Name = "dataGridViewCustomers";
            this.dataGridViewCustomers.ReadOnly = true;
            this.dataGridViewCustomers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCustomers.Size = new System.Drawing.Size(1380, 282);
            this.dataGridViewCustomers.TabIndex = 1;
            this.dataGridViewCustomers.SelectionChanged += new System.EventHandler(this.dataGridViewCustomers_SelectionChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.modify_rental_groupbox);
            this.tabPage3.Controls.Add(this.dataGridViewRentals);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1392, 613);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Rental Report";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // modify_rental_groupbox
            // 
            this.modify_rental_groupbox.Controls.Add(this.label10);
            this.modify_rental_groupbox.Controls.Add(this.rental_summary_label);
            this.modify_rental_groupbox.Controls.Add(this.return_vehicle_button);
            this.modify_rental_groupbox.Location = new System.Drawing.Point(6, 538);
            this.modify_rental_groupbox.Name = "modify_rental_groupbox";
            this.modify_rental_groupbox.Size = new System.Drawing.Size(1380, 69);
            this.modify_rental_groupbox.TabIndex = 1;
            this.modify_rental_groupbox.TabStop = false;
            this.modify_rental_groupbox.Text = "Modify Rentals";
            // 
            // rental_summary_label
            // 
            this.rental_summary_label.AutoSize = true;
            this.rental_summary_label.Location = new System.Drawing.Point(963, 29);
            this.rental_summary_label.Name = "rental_summary_label";
            this.rental_summary_label.Size = new System.Drawing.Size(41, 13);
            this.rental_summary_label.TabIndex = 1;
            this.rental_summary_label.Text = "label22";
            // 
            // return_vehicle_button
            // 
            this.return_vehicle_button.Location = new System.Drawing.Point(41, 19);
            this.return_vehicle_button.Name = "return_vehicle_button";
            this.return_vehicle_button.Size = new System.Drawing.Size(134, 32);
            this.return_vehicle_button.TabIndex = 0;
            this.return_vehicle_button.Text = "Return vehicle";
            this.return_vehicle_button.UseVisualStyleBackColor = true;
            this.return_vehicle_button.Click += new System.EventHandler(this.return_vehicle_button_Click);
            // 
            // dataGridViewRentals
            // 
            this.dataGridViewRentals.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewRentals.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewRentals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRentals.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewRentals.Name = "dataGridViewRentals";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewRentals.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewRentals.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewRentals.Size = new System.Drawing.Size(1383, 529);
            this.dataGridViewRentals.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.results_groupbox);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.max_price_search);
            this.tabPage4.Controls.Add(this.min_price_search);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.show_all_button);
            this.tabPage4.Controls.Add(this.search_button);
            this.tabPage4.Controls.Add(this.search_input_textbox);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1392, 613);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Rental Search";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // results_groupbox
            // 
            this.results_groupbox.Controls.Add(this.dataGridViewSearch);
            this.results_groupbox.Controls.Add(this.create_rental_groupbox);
            this.results_groupbox.Location = new System.Drawing.Point(14, 113);
            this.results_groupbox.Name = "results_groupbox";
            this.results_groupbox.Size = new System.Drawing.Size(1360, 481);
            this.results_groupbox.TabIndex = 7;
            this.results_groupbox.TabStop = false;
            this.results_groupbox.Text = "Results";
            // 
            // dataGridViewSearch
            // 
            this.dataGridViewSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.714285F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSearch.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSearch.Location = new System.Drawing.Point(15, 19);
            this.dataGridViewSearch.Name = "dataGridViewSearch";
            this.dataGridViewSearch.ReadOnly = true;
            this.dataGridViewSearch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSearch.Size = new System.Drawing.Size(1329, 352);
            this.dataGridViewSearch.TabIndex = 1;
            // 
            // create_rental_groupbox
            // 
            this.create_rental_groupbox.Controls.Add(this.days_renting_exclaim);
            this.create_rental_groupbox.Controls.Add(this.cust_renting_exclaim);
            this.create_rental_groupbox.Controls.Add(this.label8);
            this.create_rental_groupbox.Controls.Add(this.rental_days_select);
            this.create_rental_groupbox.Controls.Add(this.customer_combobox);
            this.create_rental_groupbox.Controls.Add(this.rent_confirm_button);
            this.create_rental_groupbox.Controls.Add(this.total_cost_label);
            this.create_rental_groupbox.Controls.Add(this.label6);
            this.create_rental_groupbox.Controls.Add(this.label5);
            this.create_rental_groupbox.Location = new System.Drawing.Point(15, 377);
            this.create_rental_groupbox.Name = "create_rental_groupbox";
            this.create_rental_groupbox.Size = new System.Drawing.Size(1329, 89);
            this.create_rental_groupbox.TabIndex = 0;
            this.create_rental_groupbox.TabStop = false;
            this.create_rental_groupbox.Text = "Create rental";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(594, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "days";
            // 
            // rental_days_select
            // 
            this.rental_days_select.Location = new System.Drawing.Point(518, 40);
            this.rental_days_select.Name = "rental_days_select";
            this.rental_days_select.Size = new System.Drawing.Size(70, 20);
            this.rental_days_select.TabIndex = 5;
            this.rental_days_select.ValueChanged += new System.EventHandler(this.rental_days_select_ValueChanged);
            // 
            // customer_combobox
            // 
            this.customer_combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.customer_combobox.FormattingEnabled = true;
            this.customer_combobox.Location = new System.Drawing.Point(106, 39);
            this.customer_combobox.Name = "customer_combobox";
            this.customer_combobox.Size = new System.Drawing.Size(259, 21);
            this.customer_combobox.TabIndex = 4;
            this.customer_combobox.SelectedIndexChanged += new System.EventHandler(this.customer_combobox_SelectedIndexChanged);
            // 
            // rent_confirm_button
            // 
            this.rent_confirm_button.Location = new System.Drawing.Point(1144, 30);
            this.rent_confirm_button.Name = "rent_confirm_button";
            this.rent_confirm_button.Size = new System.Drawing.Size(146, 36);
            this.rent_confirm_button.TabIndex = 3;
            this.rent_confirm_button.Text = "Rent";
            this.rent_confirm_button.UseVisualStyleBackColor = true;
            this.rent_confirm_button.Click += new System.EventHandler(this.rent_confirm_button_Click);
            // 
            // total_cost_label
            // 
            this.total_cost_label.AutoSize = true;
            this.total_cost_label.Location = new System.Drawing.Point(786, 42);
            this.total_cost_label.Name = "total_cost_label";
            this.total_cost_label.Size = new System.Drawing.Size(7, 13);
            this.total_cost_label.TabIndex = 2;
            this.total_cost_label.Text = "\r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(419, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Rental duration:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Customer:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(191, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "-";
            // 
            // max_price_search
            // 
            this.max_price_search.Location = new System.Drawing.Point(207, 78);
            this.max_price_search.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.max_price_search.Name = "max_price_search";
            this.max_price_search.Size = new System.Drawing.Size(62, 20);
            this.max_price_search.TabIndex = 5;
            // 
            // min_price_search
            // 
            this.min_price_search.Location = new System.Drawing.Point(123, 78);
            this.min_price_search.Name = "min_price_search";
            this.min_price_search.Size = new System.Drawing.Size(62, 20);
            this.min_price_search.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Daily cost range:";
            // 
            // show_all_button
            // 
            this.show_all_button.Location = new System.Drawing.Point(673, 28);
            this.show_all_button.Name = "show_all_button";
            this.show_all_button.Size = new System.Drawing.Size(146, 36);
            this.show_all_button.TabIndex = 2;
            this.show_all_button.Text = "Show all";
            this.show_all_button.UseVisualStyleBackColor = true;
            this.show_all_button.Click += new System.EventHandler(this.show_all_button_Click);
            // 
            // search_button
            // 
            this.search_button.Location = new System.Drawing.Point(520, 28);
            this.search_button.Name = "search_button";
            this.search_button.Size = new System.Drawing.Size(147, 36);
            this.search_button.TabIndex = 1;
            this.search_button.Text = "Search";
            this.search_button.UseVisualStyleBackColor = true;
            this.search_button.Click += new System.EventHandler(this.search_button_Click);
            // 
            // search_input_textbox
            // 
            this.search_input_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.07143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_input_textbox.Location = new System.Drawing.Point(34, 28);
            this.search_input_textbox.Name = "search_input_textbox";
            this.search_input_textbox.Size = new System.Drawing.Size(438, 36);
            this.search_input_textbox.TabIndex = 0;
            this.search_input_textbox.TextChanged += new System.EventHandler(this.search_input_textbox_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(357, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "label10";
            // 
            // cust_renting_exclaim
            // 
            this.cust_renting_exclaim.AutoSize = true;
            this.cust_renting_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cust_renting_exclaim.ForeColor = System.Drawing.Color.Red;
            this.cust_renting_exclaim.Location = new System.Drawing.Point(371, 38);
            this.cust_renting_exclaim.Name = "cust_renting_exclaim";
            this.cust_renting_exclaim.Size = new System.Drawing.Size(16, 22);
            this.cust_renting_exclaim.TabIndex = 7;
            this.cust_renting_exclaim.Text = "!";
            // 
            // days_renting_exclaim
            // 
            this.days_renting_exclaim.AutoSize = true;
            this.days_renting_exclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.92857F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.days_renting_exclaim.ForeColor = System.Drawing.Color.Red;
            this.days_renting_exclaim.Location = new System.Drawing.Point(622, 37);
            this.days_renting_exclaim.Name = "days_renting_exclaim";
            this.days_renting_exclaim.Size = new System.Drawing.Size(16, 22);
            this.days_renting_exclaim.TabIndex = 8;
            this.days_renting_exclaim.Text = "!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1424, 771);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "MRRC";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.mod_vehicle_groupbox.ResumeLayout(false);
            this.mod_vehicle_groupbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mod_dailyrate_updown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mod_seats_updown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVehicles)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.cust_main_groupbox.ResumeLayout(false);
            this.mod_add_cust_groupbox.ResumeLayout(false);
            this.mod_add_cust_groupbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomers)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.modify_rental_groupbox.ResumeLayout(false);
            this.modify_rental_groupbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRentals)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.results_groupbox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSearch)).EndInit();
            this.create_rental_groupbox.ResumeLayout(false);
            this.create_rental_groupbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rental_days_select)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.max_price_search)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.min_price_search)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridViewCustomers;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button remove_cust_button;
        private System.Windows.Forms.GroupBox cust_main_groupbox;
        private System.Windows.Forms.Button modify_cust_button;
        private System.Windows.Forms.Button add_cust_button;
        private System.Windows.Forms.GroupBox mod_add_cust_groupbox;
        private System.Windows.Forms.Label dob_label;
        private System.Windows.Forms.Label gender_label;
        private System.Windows.Forms.Label ln_label;
        private System.Windows.Forms.Label fn_label;
        private System.Windows.Forms.Label title_label;
        private System.Windows.Forms.Label custid_label;
        private System.Windows.Forms.Button mod_cust_submit_button;
        private System.Windows.Forms.Button mod_cust_cancel_button;
        private System.Windows.Forms.TextBox mod_dob_textbox;
        private System.Windows.Forms.TextBox mod_ln_textbox;
        private System.Windows.Forms.TextBox mod_fn_textbox;
        private System.Windows.Forms.TextBox mod_title_textbox;
        private System.Windows.Forms.TextBox mod_custid_textbox;
        private System.Windows.Forms.Label mod_cust_fn_exclaim;
        private System.Windows.Forms.Label mod_cust_title_exclaim;
        private System.Windows.Forms.Label mod_cust_dob_exclaim;
        private System.Windows.Forms.Label mod_cust_gender_exclaim;
        private System.Windows.Forms.Label mod_cust_ln_exclaim;
        private System.Windows.Forms.ComboBox gender_select;
        private System.Windows.Forms.GroupBox mod_vehicle_groupbox;
        private System.Windows.Forms.DataGridView dataGridViewVehicles;
        private System.Windows.Forms.DataGridView dataGridViewRentals;
        private System.Windows.Forms.TextBox search_input_textbox;
        private System.Windows.Forms.GroupBox results_groupbox;
        private System.Windows.Forms.DataGridView dataGridViewSearch;
        private System.Windows.Forms.GroupBox create_rental_groupbox;
        private System.Windows.Forms.NumericUpDown rental_days_select;
        private System.Windows.Forms.ComboBox customer_combobox;
        private System.Windows.Forms.Button rent_confirm_button;
        private System.Windows.Forms.Label total_cost_label;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown max_price_search;
        private System.Windows.Forms.NumericUpDown min_price_search;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button show_all_button;
        private System.Windows.Forms.Button search_button;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox mod_make_textbox;
        private System.Windows.Forms.TextBox mod_rego_textbox;
        private System.Windows.Forms.Button vehicle_cancel_button;
        private System.Windows.Forms.Button vehicle_submit_button;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button modify_vehicle_button;
        private System.Windows.Forms.NumericUpDown mod_dailyrate_updown;
        private System.Windows.Forms.TextBox mod_colour_textbox;
        private System.Windows.Forms.NumericUpDown mod_seats_updown;
        private System.Windows.Forms.ComboBox mod_fuel_combobox;
        private System.Windows.Forms.ComboBox mod_trans_combobox;
        private System.Windows.Forms.TextBox mod_year_textbox;
        private System.Windows.Forms.ComboBox mod_class_combobox;
        private System.Windows.Forms.TextBox mod_model_textbox;
        private System.Windows.Forms.Button add_vehicle_button;
        private System.Windows.Forms.Button remove_vehicle_button;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox modify_rental_groupbox;
        private System.Windows.Forms.Label rental_summary_label;
        private System.Windows.Forms.Button return_vehicle_button;
        private System.Windows.Forms.Label mod_rego_exclaim;
        private System.Windows.Forms.Label mod_year_exclaim;
        private System.Windows.Forms.Label mod_class_exclaim;
        private System.Windows.Forms.Label mod_model_exclaim;
        private System.Windows.Forms.Label mod_make_exclaim;
        private System.Windows.Forms.Label mod_cust_id_exclaim;
        private System.Windows.Forms.ComboBox mod_gps_combobox;
        private System.Windows.Forms.ComboBox mod_sunroof_combobox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label days_renting_exclaim;
        private System.Windows.Forms.Label cust_renting_exclaim;
    }
}

